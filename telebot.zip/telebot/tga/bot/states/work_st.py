from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext

class work_st(StatesGroup):
  answer = State()
  result = State()
  return_answer = State()