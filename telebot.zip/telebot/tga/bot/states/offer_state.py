from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext

class offer(StatesGroup):
	name = State()
	online = State()
	theme = State()
	subs = State()
	start = State()
	stop = State()
	text = State()