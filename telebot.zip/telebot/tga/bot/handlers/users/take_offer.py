from aiogram import types
from aiogram.dispatcher.filters import Command
import datetime

from loader import dp, bot
from keyboards.inline import apruv
from sql import AddUsers, offers


@dp.callback_query_handler(text='take')
async def takeOffer(c):
  bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  AU = AddUsers()
  bloger = AU.getBloger(c.from_user.id)
  id_ads = str(c.message.text.split()[0]) + 'p'
  id_ads = id_ads[1 : -1]
  name = str(c.message.text.split()[1]) + 'p'
  name = name[1 : -1]
  await bot.send_message(id_ads, f'#{c.from_user.id}\n#{name}\n#{bloger} \nБлогер https://www.instagram.com/{bloger}/ откликнулся на ваш оффер: \n{c.message.text}', reply_markup=apruv)