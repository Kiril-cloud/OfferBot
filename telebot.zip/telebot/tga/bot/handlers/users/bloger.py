from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
import datetime
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from states import reg_bloger
from sql import AddUsers, parser
from loader import dp, bot
from keyboards.inline import bloger_menu


rb = reg_bloger()


@dp.callback_query_handler(text='blog')
async def blog(c: CallbackQuery, state: FSMContext):
  bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  try:
    AU = AddUsers()
    AU.AddBloger(c.from_user.id, False, 0, 0, 0)
    rb = reg_bloger()
    
    if AU.getBlogerVer(c.from_user.id) == 'True':
      await c.message.edit_text('Выберите действи на клавиатуре:', reply_markup=bloger_menu)
    else:
      await c.message.edit_text('Для регистрации пришлите свой номер телефона:')
      await rb.phone.set()
  except Exception as e:
    print(e)
  
@dp.message_handler(state=rb.phone)
async def setPhone(message: types.message, state: FSMContext):
  rb = reg_bloger()
  AU = AddUsers()
  await rb.url.set()
  AU.setPhone(message.from_user.id, message.text)
  await message.answer("""1. Добавьте в профиль emoji ✈️🍍⛰️🌋 \n2. Пришлите никнейм в инстаграм, мы проверим что Emoji в описании и верифицируем аккаунт \n3.Вы можете удалить Emoji сразу после верификации""")
  
@dp.message_handler(state=rb.url)
async def setUrl(message: types.message, state: FSMContext):
  await message.answer('Минитку, проверяем...')
  rb = reg_bloger()
  AU = AddUsers()
  p = parser()
  await state.finish()
  AU.setUrl(message.from_user.id, message.text)
  state = p.getVer(message.text)
  if state == True:
    AU.setStatus(message.from_user.id, True)
    await message.answer('Поздравляем! Вы подтвердили свой статус в нашем боте.', reply_markup=bloger_menu)
  else:
    AU.setStatus(message.from_user.id, False)
    await message.answer('Ой... Что-то пошло не так! Возможно вы указали неверный ник или не правильно добавили эмоджи.')
    

@dp.message_handler(commands = ['bloger'])
async def blogMessage(message, state: FSMContext):
  try:
    AU = AddUsers()
    AU.AddBloger(message.from_user.id, False, 0, 0, 0)
    rb = reg_bloger()
    
    if AU.getBlogerVer(message.from_user.id) == 'True':
      await message.answer('Выберите действи на клавиатуре:', reply_markup=bloger_menu)
    else:
      await message.answer('Для регистрации пришлите свой номер телефона:')
      await rb.phone.set()  
  except Exception as e:
    print(e)
  