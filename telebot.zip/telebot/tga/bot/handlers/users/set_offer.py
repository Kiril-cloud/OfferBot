from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
import datetime

from loader import dp, bot
from sql import Offers
from keyboards.inline import create_offer
from keyboards.inline import offer
from states import offer_states
from sql import AddUsers


offer_state = offer_states()

@dp.callback_query_handler(text=['name', 'online', 'theme', 'subs', 'stop', 'text'])
async def set_offer(c: CallbackQuery, state: FSMContext):
  bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  try:
    offer_state = offer_states()
    AU = AddUsers()
    if c.data == 'name':
      AU.setOffers(c.from_user.id)
      await offer_state.name.set()
      await c.message.edit_text('Введите название оффера:')
      
    if c.data == 'online':
      await offer_state.online.set()
      await c.message.edit_text('Ваш оффер можно выполнить не выходя из дома? Если да напишите онлайн, ели нет пришлите название города.')
      
    if c.data == 'theme':
      await offer_state.theme.set()
      await c.message.edit_text('Введите тематику оффера:')
    
    if c.data == 'subs':
      await offer_state.subs.set()
      await c.message.edit_text('Введите минимальное количество подписчиков у блогера чтобы он мог выполнить оффер:')
      
    if c.data == 'stop':
      await offer_state.stop.set()
      await c.message.edit_text('Введите дату окончания действия оффера в формате дд.мм.гггг:')
      
    if c.data == 'text':
      await offer_state.text.set()
      await c.message.edit_text('Введите текст задания оффера:')
      
  except Exception as e:
    print(e, 52)
    
@dp.message_handler(state=offer_state.name)
async def setName(message: types.message, state: FSMContext):
  try:
    offers = Offers()
    offer_state = offer_states()
    await state.finish()
    offers.setName(message.from_user.id, message.text, datetime.date.today(), message.message_id)
    
    res = offers.getOfferM(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except Exception as e:
    print(e, 71)
  
  
@dp.message_handler(state=offer_state.online)
async def setCiti(message: types.message, state: FSMContext):
  try:
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOfferM(message.from_user.id)[1]
    await state.update_data(online=message.text)
    await state.finish()
    offers.setOnline(message.from_user.id, name, message.text)
    
    res = offers.getOfferM(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
  
@dp.message_handler(state=offer_state.theme)
async def setTheme(message: types.message, state: FSMContext):
  try:
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOfferM(message.from_user.id)[1]
    await state.update_data(theme=message.text)
    await state.finish()
    offers.setTheme(message.from_user.id, name, message.text)
    
    res = offers.getOfferM(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except:
    pass
  
@dp.message_handler(state=offer_state.subs)
async def setSubs(message: types.message, state: FSMContext):
  try:
    s = int(message.text)
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOfferM(message.from_user.id)[1]
    await state.update_data(subs=message.text)
    await state.finish()
    offers.setSubs(message.from_user.id, name, message.text)
    
    res = offers.getOfferM(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except Exception as e:
    print(e)
    offer_state = offer_states()
    await offer_state.subs.set()
    await message.answer('Неверный формат! Укажите только число:')
  
@dp.message_handler(state=offer_state.stop)
async def setStop(message: types.message, state: FSMContext):
  try:
    date = datetime.datetime.strptime(message.text, '%d.%m.%Y')
    offers = Offers()
    offer_state = offer_states()
    data = await state.get_data()
    name = offers.getOfferM(message.from_user.id)[1]
    await state.update_data(stop=message.text)
    await state.finish()
    offers.setStop(message.from_user.id, name, date)
    
    res = offers.getOfferM(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
    
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except Exception as e:
    offer_state = offer_states()
    await offer_state.stop.set()
    await message.answer(f'Неверный формат! Укажите дату в формате дд.м.гггг: {e}')
  
@dp.message_handler(state=offer_state.text)
async def setText(message: types.message, state: FSMContext):
  try:
    offers = Offers()
    offer_state = offer_states()
    name = offers.getOfferM(message.from_user.id)[1]
    await state.finish()
    offers.setText(message.from_user.id, name, message.text)
      
    res = offers.getOfferM(message.from_user.id)
    name = res[1]
    citi = res[2]
    theme = res[3]
    subs = res[4]
    start = res[5]
    stop = res[6]
    texts = res[7]
      
    text = f'Название: {name}\n Тематика: {theme}\n Город: {citi}\n Начало: {start}\n Конец: {stop}\n Минимальное число подписчиков: {subs}\n Текст задания: {texts}'
    await message.answer(text, reply_markup = create_offer)
  except Exception as e:
    pass