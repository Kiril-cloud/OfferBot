from aiogram import types

from loader import dp, bot


@dp.message_handler(user_id = )
async def ban(message: types.Message):
  await message.answer('За нарушение правил вы были заблокированы! Наш бот внес вас с черный список!')
  raise Exception('Flud')