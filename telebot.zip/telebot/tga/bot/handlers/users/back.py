from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from loader import dp, bot
from keyboards.inline import offer


@dp.callback_query_handler(text='back')
async def back(c: CallbackQuery, state: FSMContext):
  bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  if c.data == 'back':
    await state.finish()
    await c.message.answer('Выберите действие на клавиатуре ниже:', reply_markup = offer)