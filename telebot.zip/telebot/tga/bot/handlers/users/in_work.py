from aiogram import types
from aiogram.dispatcher.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from loader import dp, bot
from sql import AddUsers, Offers


@dp.callback_query_handler(text='in_work')
async def in_work(c):
  bot.delete_message(chat_id = c.from_user.id, message_id = c.message.message_id)
  offers = Offers()
  AU = AddUsers()
  url = AU.getBloger(c.from_user.id)
  names = offers.getWork(url)
  
  list_offer = InlineKeyboardMarkup(row_width=2)
  for name in names:
    name = InlineKeyboardButton(name, callback_data = name)
    list_offer.add(name)
    
  if names == []:
    await c.message.answer('Вы пока что не взяли ни одного оффера.')
  else:
    await c.message.answer('Вот список офферов в работе.', reply_markup = list_offer)