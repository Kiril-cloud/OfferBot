from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

create_offer = InlineKeyboardMarkup(row_width=1)
name = InlineKeyboardButton('Название', callback_data = 'name')
online = InlineKeyboardButton('Город', callback_data = 'online')
theme = InlineKeyboardButton('Тематика', callback_data = 'theme')
subs = InlineKeyboardButton('Минимальное количество подписчиков', callback_data = 'subs')
stop = InlineKeyboardButton('Дата окончания', callback_data = 'stop')
text = InlineKeyboardButton('Текст', callback_data = 'text')
back = InlineKeyboardButton('Сохранить и выйти', callback_data = 'back')
create_offer.add(name, online, theme, subs, stop, text, back)