import sqlite3
import datetime


class AddUsers():
  def __init__(self):
    self.db = sqlite3.connect("tga/bot.db")
    self.sql = self.db.cursor()
    try:
      self.sql.execute('DROP TRIGGER modered')
      a = 'Пусто'
      self.sql.execute(f"""CREATE TRIGGER modered AFTER UPDATE OF cost ON ugc_moder BEGIN INSERT INTO ugc_offers SELECT * FROM ugc_moder WHERE cost > -1; DELETE FROM ugc_moder WHERE cost > -1; END;""")
    except Exception as e:
      print(e)
    
  def AddADS(self, id, status, date):
    self.sql.execute(f"SELECT user_id FROM ugc_ads WHERE id == {id}")
    if self.sql.fetchone() == None:
      self.sql.execute("INSERT INTO ugc_ads VALUES(?, ?, ?, ?, ?)", (id, id, date, 0, status))
      self.db.commit()

      self.sql.execute("""SELECT new_users FROM ugc_stats WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)""")
      new_ads = str(self.sql.fetchone()).replace("'", "").replace('[', '').replace(']', '').replace('(', '').replace(')', '').replace(',', '')
      print(new_ads)
      new_blogers = int(new_ads[new_ads.rfind('/')+1 : -8])
      new_ads = int(new_ads[0 : new_ads.find('р')])+1
      new_users=str(new_ads) + 'рекламодателей' + '/' + str(new_blogers) + 'блогеров'
      
      
      self.sql.execute("""SELECT * FROM ugc_ads""")
      old_ads = len(self.sql.fetchall())

      self.sql.execute("""SELECT * FROM ugc_blogers""")
      old_blogers = len(self.sql.fetchall())
      
      old_users = str(old_ads) + 'рекламодателей' + '/' + str(old_blogers) + 'блогеров'
      print(old_blogers, old_users, old_ads)
      self.sql.execute(f"""UPDATE ugc_stats SET old_users = '{old_users}' WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)""")
      self.sql.execute(f"""UPDATE ugc_stats SET new_users = '{new_users}' WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)""")

      self.db.commit()
      
  def setOffers(self, id):
    self.sql.execute(f"SELECT offers FROM ugc_ads WHERE user_id == {id} ")
    offers = self.sql.fetchone()[0]
    offers = int(offers)
    offers+=1
    self.sql.execute(f"UPDATE ugc_ads SET offers = {offers} WHERE user_id == {id}")
    self.db.commit()
    
  def AddBloger(self, id, status, phone, email, date):
    self.sql.execute(f"SELECT id FROM ugc_blogers WHERE user_id == {id}")
    if self.sql.fetchone() == None:
      self.sql.execute("INSERT INTO ugc_blogers VALUES(?, ?, ?, ?, ?, ?)", (id, id, phone, '0', status, date))

      self.db.commit()

      self.sql.execute("""SELECT new_users FROM ugc_stats WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)""")
      new_ads = str(self.sql.fetchone()).replace("'", "").replace('[', '').replace(']', '').replace('(', '').replace(')', '').replace(',', '')
      print(new_ads)
      new_blogers = int(new_ads[new_ads.rfind('/')+1 : -8])+1
      new_ads = int(new_ads[0 : new_ads.find('р')])
      new_users=str(new_ads) + 'рекламодателей' + '/' + str(new_blogers) + 'блогеров'
      
      
      self.sql.execute("""SELECT * FROM ugc_ads""")
      old_ads = len(self.sql.fetchall())

      self.sql.execute("""SELECT * FROM ugc_blogers""")
      old_blogers = len(self.sql.fetchall())
      
      old_users = str(old_ads) + 'рекламодателей' + '/' + str(old_blogers) + 'блогеров'
      print(old_blogers, old_users, old_ads)
      self.sql.execute(f"""UPDATE ugc_stats SET old_users = '{old_users}' WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)""")
      self.sql.execute(f"""UPDATE ugc_stats SET new_users = '{new_users}' WHERE rowid = (SELECT MAX(rowid) FROM ugc_stats)""")

      self.db.commit()
      
  def setPhone(self, id, phone):
    self.sql.execute(f"UPDATE ugc_blogers SET phone = '{phone}' WHERE user_id == {id}")
    self.db.commit()
    
  def setUrl(self, id, url):
    self.sql.execute(f"UPDATE ugc_blogers SET url = '{url}' WHERE user_id == {id}")
    self.db.commit()
    
  def setStatus(self, id, status):
    self.sql.execute(f"UPDATE ugc_blogers SET status = '{status}' WHERE user_id == {id}")
    self.db.commit()
    
  def getOffer(self, follow):
    self.sql.execute(f"""SELECT * FROM ugc_offers""")
    results = self.sql.fetchall()
    res = []
    for result in results:
      names = str(result[2])
      subs=-1
      if subs < follow:
        res.append(names)
    print(res)
    return res
    
  def getOffer_list(self, follow):
    self.sql.execute(f"""SELECT * FROM ugc_offers""")
    results = self.sql.fetchall()
    res = []
    for result in results:
      names = str(result[2])
      citi = str(result[3])
      theme = str(result[4])
      subs = int(result[5])
      start = str(result[6])
      stop = str(result[7])
      texts = str(result[8])
      if subs < follow:
        res.append(0)
        res.append(names)
        res.append(citi)
        res.append(theme)
        res.append(subs)
        res.append(start)
        res.append(stop)
        res.append(texts)
    print(res)
    return res

  def getUsers(self):
    date = datetime.date.today() - datetime.timedelta(days=1)
    self.sql.execute(f"SELECT id FROM ugc_ads WHERE date > '{date}' ")
    new = len(self.sql.fetchall())
    self.sql.execute(f"SELECT id FROM ugc_ads WHERE date < '{date}' ")
    try:
      old = len(self.sql.fetchone())
    except:
      old = 0

    res = [new, old]
    return res
    
  def getActive(self):
    self.sql.execute("SELECT offers FROM ugc_ads")
    actives = self.sql.fetchall()
    out = 0
    print(list(actives))
    for active in list(actives):
      active = str(active)
      active = active.replace('(', '')
      active = active.replace(',', '')
      active = active.replace(')', '')
      active = active.replace('\'', '')
      active = int(active)
      if active > 0:
        out+=1
        print(out)
    return out
    
  def getBloger(self, id):
    self.sql.execute(f"SELECT url FROM ugc_blogers WHERE user_id == {id}")
    url = self.sql.fetchone()[0]
    print(url)
    return url
    
  def getBlogerVer(self, id):
    self.sql.execute(f"SELECT status FROM ugc_blogers WHERE user_id == {id}")
    status = self.sql.fetchone()[0]
    return status
