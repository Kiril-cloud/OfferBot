import instaloader

class parser():
  def init(self):
    pass
    
  def getVer(self, name):
    L = instaloader.Instaloader()
    desc = instaloader.Profile.from_username(L.context, name).biography
    if desc[-6 : -1] == '✈️🍍⛰️':
      return True
    else:
      return False
      
  def getFollow(self, name):
    L = instaloader.Instaloader()
    follow = instaloader.Profile.from_username(L.context, name).followers
    return follow