from django.db import models


class ADS(models.Model):
  stat = [
    ('True', 'Normal'),
    ('False', 'Blocked')
    ]
  user_id = models.TextField(verbose_name="user_id")
  status = models.CharField('status', choices=stat, max_length=50, blank=True, db_index=True)
  date = models.TextField(verbose_name="date")
  offers = models.TextField(verbose_name="offers")
  
  class Meta:
    verbose_name = 'Рекламодатели'
    verbose_name_plural = 'Рекламодатели'


class Offers(models.Model):
  user = models.TextField(verbose_name="Рекламодетель", unique=False)
  name = models.TextField(verbose_name="Название")
  online = models.TextField(verbose_name="Город", unique=False)
  theme = models.TextField(verbose_name="Тематика", unique=False)
  subs = models.TextField(verbose_name="Мин. подписчиков", unique=False)
  start = models.TextField(verbose_name="Дата начала", unique=False)
  stop = models.TextField(verbose_name="Дата окончания", unique=False)
  text = models.TextField(verbose_name="Описание", unique=False)
  cost = models.TextField(verbose_name="Цена", unique=False)
  bloger = models.TextField(verbose_name="Блогер", unique=False, default='0')
  
  class Meta:
    verbose_name = 'Оффер'
    verbose_name_plural = 'Оффер'
  
  
class Moder(models.Model):
  user = models.TextField(verbose_name="Рекламодетель", unique=False)
  name = models.TextField(verbose_name="Название")
  online = models.TextField(verbose_name="Город", unique=False)
  theme = models.TextField(verbose_name="Тематика", unique=False)
  subs = models.TextField(verbose_name="Мин. подписчиков", unique=False)
  start = models.TextField(verbose_name="Дата начала", unique=False)
  stop = models.TextField(verbose_name="Дата окончания", unique=False)
  text = models.TextField(verbose_name="Описание", unique=False)
  cost = models.TextField(verbose_name="Цена", unique=False)
  bloger = models.TextField(verbose_name="Блогер", unique=False, default='0')
  class Meta:
    verbose_name = u'Модерация'
    verbose_name_plural = u'Модерация'


class Blogers(models.Model):
  stat = [
    ('True', 'Нормальный'),
    ('False', 'Заблокированный')
    ]
  user_id = models.TextField(verbose_name='user_id')
  phone = models.TextField(verbose_name="Номер телефона")
  url = models.TextField(verbose_name="Ник в инстаграме")
  status = models.CharField('Статус', choices=stat, max_length=50, blank=True, db_index=True)
  date = models.TextField(verbose_name="Дата")

  class Meta:
    verbose_name = 'Блогеры'
    verbose_name_plural = u'Блогеры'


class Stats(models.Model):
  new_users = models.TextField(verbose_name='Новые пользователи')
  old_users = models.TextField(verbose_name='Всего пользователей')
  active_users = models.TextField(verbose_name='Активные пользователь')

  moder_offers = models.TextField(verbose_name='Офферы на модерации')
  active_offers = models.TextField(verbose_name='Активные офферы')
  work_offer = models.TextField(verbose_name='Офферы в работе')

  class Meta:
    verbose_name = 'Статистика'
    verbose_name_plural = u'Cтатистика'